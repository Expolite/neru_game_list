var character = document.getElementById("character");
var block = document.getElementById("block");

var char01 = document.getElementById("char_01");
var char02 = document.getElementById("char_02");

var intervalId1, intervalId2;


function jump() {
    if(character.classList != "animateJump"){
        character.classList.add("animateJump");     // add Class
    }

    // remove class after .5 second
    setTimeout(function(){
        character.classList.remove("animateJump");      // remove Class
    },500)
}






// Game Over - when block hit the character.
var getScore = 0;
// Initialize the score display
document.getElementById("totalScore").innerHTML = "Score: " + getScore;

var checkDead = setInterval(function(){
    var characterTop = parseInt(window.getComputedStyle(character).getPropertyValue("top"));
    var blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));

    // Game over
    if(blockLeft < 20 && blockLeft > 0 && characterTop >= 130) {
        block.style.animation = "none";     // remove animation
        // clearInterval(checkDead);
        clearInterval(intervalId1);
        clearInterval(intervalId2);
        alert("Game Over.");
    }

    // Debugging
    document.getElementById("getBlock").innerHTML = blockLeft;

    // Check if character successfully avoids the block and get the score
    if (blockLeft < -20 && blockLeft < 0 && characterTop <= 130) {        
        // Increment the score
        getScore++;
        document.getElementById("totalScore").innerHTML = "Score: " + getScore;

        block.style.animation = "none";     // remove block animation
        delayGameStart();    // start block animation

    }
},20);  // adjust the value until you get the right score.


// Delayed call start game
function delayGameStart() {
    setTimeout(function(){
        // start block animation
        block.style.animation = "block 1s infinite linear";     // add animation

    },100);
}









// START GAME
function startGame() {
    // reset Score
    getScore = 0;
    document.getElementById("totalScore").innerHTML = "Score: " + getScore;
    if(block.classList != "run_animation") {
        // start countdown
        startTimer();
    }
}






// Press space bar to jump
// Action button & Jump key - detect if space bar is pressed

// Cooldown variables
const cooldownTime = 500; // 500 milliseconds cooldown
let lastExecutionTime = 0;

// Function to handle keydown event
function handleKeyDown(event) {
    const currentTime = Date.now();
    const elapsedTime = currentTime - lastExecutionTime;

    if (elapsedTime >= cooldownTime) {
        // Enough time has passed since the last execution
        lastExecutionTime = currentTime;
        // alert('Button clicked!');

        // Check if the pressed key is the space bar (keyCode 32)
        if (event.keyCode === 32) {
            jump();
        }
    }
}

// Attach the event listener to the document
document.addEventListener('keydown', handleKeyDown);










// COUNTDOWN TIMER and GAME START

function startTimer() {
    // Set the initial value of the countdown timer to 3 seconds
    var timeleft = 3;

    // Display countdown - modal
    countdown_display_container.style.display = "block";

    // Use setInterval to execute a function every 1000 milliseconds (1 second)
    var downloadTimer = setInterval(function() {
        // Check if the countdown has reached or passed 0 seconds
        if (timeleft <= 0) {
            clearInterval(downloadTimer);
            document.getElementById("countdown").innerHTML = "Go!";

            // remove countdown modal in 1 second
            setTimeout(function(){
                countdown_display_container.style.display = "none";
                document.getElementById("countdown").innerHTML = "";    // clear/remove "Go" text
            },1000);


            // start game animation
            // run animation in 1.5 second
            setTimeout(function(){
                gameStart();
            },1500);

        } else {
            // If still counting down, display the remaining seconds
            document.getElementById("countdown").innerHTML = timeleft;
        }
        // Decrement the countdown timer by 1 second
        timeleft -= 1;
    }, 1000);
}








// GAME START
function gameStart() {

    // run animation
    block.style.animation = "block 1s infinite linear";     // add animation

    characterRunning();
}







// Character running animation
function characterRunning() {
    // character animation running
    // character 01
    intervalId1 = setInterval(function(){
        char01.style.display = "none";
        char02.style.display = "block";
    },200);    // every 1 seconds

    // character 02
    intervalId2 = setInterval(function(){
        char01.style.display = "block";
        char02.style.display = "none";
    },400);    // every 2 seconds
}


// Function to stop the intervals
function stopCharacterRunning() {
    clearInterval(intervalId1);
    clearInterval(intervalId2);
    clearInterval(checkDead);
}


